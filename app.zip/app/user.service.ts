import { Injectable } from '@angular/core';
import { User } from './user.module';

@Injectable()
export class UserService{

    earr=[  new User("bharat@0808","bharat","khandare","Pune","15/06/1998",9284753536),
            new User("varad@1010","varad","arthamvar","Parbhani","10/05/1999",9281153500),
            new User("ganesh@0505","ganesh","gaikwad","Mumbai","05/03/2000",9284715248),
            new User("krishna@0101","krishna","deshmukh","Pune","01/04/2000",9284152426),
            
        ];


        addUser(e:User){
            console.log(e);
            this.earr.push(e);
        }
        updateUser(e:User){
            for(let a of this.earr){
                if(a.uname==e.uname){
                    a.fname=e.fname;
                    a.lname=e.lname;
                    a.city=e.city;
                    a.date=e.date;
                    a.mno=a.mno;
                }
            }
        }
        deleteUser(e:User){
            for(let i=0;i<this.earr.length;i++){
                if(this.earr[i].uname==e.uname){
                    this.earr.splice(i,1);
                }
            }
        }

        getAll():User[]{
            console.log("In getAll");
            console.log(this.earr);
            return this.earr;
        }   
}