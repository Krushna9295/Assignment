import { Component, OnInit } from '@angular/core';
import { User } from '../user.module';
import { UserService } from '../user.service';

@Component({
    selector:'etab',
    templateUrl:'./etab.component.html',
    styleUrls:['./etab.component.css']
})
export class EtabComponent implements OnInit{
    earr:User[];
    flag=false;
    eob:User;

    constructor(private eservice:UserService){}

    ngOnInit(){
        this.earr=this.eservice.getAll();
        console.log(this.earr);
    }
    editUser(e:User){
        this.flag=true;
        this.eob=e;
    }
    deleteUser(e:User){
        this.eservice.deleteUser(e);
    }
    addUser(){
        this.flag=true;
        
    }

}