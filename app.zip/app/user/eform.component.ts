import { Component, EventEmitter, Input, Output, SimpleChanges } from '@angular/core';
import { User } from '../user.module';
import { UserService } from '../user.service';

@Component({
    selector:'eform',
    templateUrl:'./eform.component.html',
    styleUrls:['./eform.component.css']
})

export class EformComponent{
    uname:string;
    fname:string;
    lname:string;
    city:string;
    date:string;
    mno:number;

    constructor(private eservice:UserService){}

    @Output() myevent=new EventEmitter();
    @Input("upemp") emp:User;
    ngOnChanges(change:SimpleChanges){
        if(change["emp"].currentValue!=change["emp"].previousValue){
            this.uname=this.emp.uname;
            this.fname=this.emp.fname;
            this.lname=this.emp.lname;
            this.city=this.emp.city;
            this.date=this.emp.date;
            this.mno=this.emp.mno;
        }
    }
    addUser(){
        let e=new User(this.uname,this.fname,this.lname,this.city,this.date,this.mno);
        this.eservice.addUser(e);
        this.uname="";
        this.fname="";
        this.lname="";
        this.city="";
        this.date="";
        this.mno=0;

        this.myevent.emit(false);
        
    }
    updateUser(){
        let e=new User(this.uname,this.fname,this.lname,this.city,this.date,this.mno);
        this.eservice.updateUser(e);
        this.uname="";
        this.fname="";
        this.lname="";
        this.city="";
        this.date="";
        this.mno=0;
        this.myevent.emit(false);
    }

}