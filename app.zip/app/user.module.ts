export class User{
    uname:string;
    fname:string;
    lname:string;
    city:string;
    date:string;
    mno:number;
    

    constructor(uname:string,fname:string,lname:string,city:string,date:string,mno:number){
        this.uname=uname;
        this.fname=fname;
        this.lname=lname;
        this.city=city;
        this.date=date;
        this.mno=mno;
    }
}